﻿using _43996_FirmanAbdulJabar.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using MySql.Data.MySqlClient;
using MySqlX.XDevAPI;
using System.Diagnostics;


namespace _43996_FirmanAbdulJabar.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly MyGlobalVariable _MyGlobalVariable;

        public HomeController(ILogger<HomeController> logger, IOptions<MyGlobalVariable> myGlobalVariable)
        {
            _logger = logger;
            _MyGlobalVariable = myGlobalVariable.Value;
        }

        public IActionResult Index()
        {
            if (HttpContext.Session.GetInt32("id") > 0) {
                ViewBag.username = HttpContext.Session.GetString("username");
                ViewBag.id = HttpContext.Session.GetInt32("id");
                return View();
            }
            return RedirectToAction("Login");
        }

        public IActionResult Login()
        {
            return View();
        }

        public IActionResult ActionLogin(RegisterModel usr)
        {

            string constr = _MyGlobalVariable.MySqlConString;
            Int32 Id = 0;
            string Username = "";
            if (constr != null)
            {
                string query = "SELECT id, username  FROM user WHERE username = @username AND password = @password;";
                using (MySqlConnection con = new MySqlConnection(constr))
                {
                    using (MySqlCommand cmd = new MySqlCommand(query))
                    {
                        cmd.Connection = con;
                        con.Open();

                        cmd.Parameters.AddWithValue("@username", usr.Username);
                        cmd.Parameters.AddWithValue("@password", usr.Password);

                        using (MySqlDataReader sdr = cmd.ExecuteReader())
                        {
                            while (sdr.Read())
                            {
                                Id = Convert.ToInt32(sdr["ID"]);
                                Username = sdr["username"].ToString();
                                HttpContext.Session.SetString("username", Username);
                                HttpContext.Session.SetInt32("id", Id);

                            }

                        }
                        con.Close();
                    }
                }

            }
            return RedirectToAction("Index", "Home");
        }


        public IActionResult Privacy()
        {
            return View();
        }

        public IActionResult Register()
        {
            return View();
        }

        public IActionResult PartialViewAction()
        {
            ViewBag.message = "This message from controller";
            return PartialView("PartialView");
        }

        [HttpPost]
        public IActionResult RegisterAction(RegisterModel mdl) 
        {
            ViewBag.RegisterStatus = $"User {mdl.Username} Successfully Register";
            return View("Index");
        }

        public IActionResult GetListUser()
        {
            List<RegisterModel> getListUser = new List<RegisterModel>();
            string constr = _MyGlobalVariable.MySqlConString;
            if (constr != null)
            {
                string query = "SELECT ID, username, password, Name, Gender FROM user;";
                using (MySqlConnection con = new MySqlConnection(constr))
                {
                    using (MySqlCommand cmd = new MySqlCommand(query))
                    {
                        cmd.Connection = con;
                        con.Open();
                        using (MySqlDataReader sdr = cmd.ExecuteReader())
                        {
                            while (sdr.Read())
                            {
                                getListUser.Add(new RegisterModel
                                {
                                    Id = Convert.ToInt64(sdr["ID"]),
                                    Username = sdr["username"].ToString(),
                                    Password = sdr["password"].ToString(),
                                    Name = sdr["Name"].ToString(),
                                    Gender = sdr["Gender"].ToString()
                                });
                            }
                        }
                        con.Close();
                    }
                }
            }
            return View(getListUser);
        }

        public IActionResult CreateUser()
        {
            return View();
        }

        public IActionResult CreateUserSubmit(RegisterModel mdl)
        {
            if (ModelState.IsValid)
            {
                string constr = _MyGlobalVariable.MySqlConString;
                if (constr != null)
                {
                    string query = "INSERT INTO user (ID, username, password, Name, Gender) VALUES (@Id, @username, @password, @Name, @Gender);";
                    using (MySqlConnection con = new MySqlConnection(constr))
                    {
                        using (MySqlCommand cmd = new MySqlCommand(query))
                        {
                            cmd.Connection = con;
                            con.Open();
                            cmd.Parameters.AddWithValue("@Id", mdl.Id);
                            cmd.Parameters.AddWithValue("@username", mdl.Username);
                            cmd.Parameters.AddWithValue("@password", mdl.Password);
                            cmd.Parameters.AddWithValue("@Name", mdl.Name);
                            cmd.Parameters.AddWithValue("@Gender", mdl.Gender);
                            cmd.ExecuteNonQuery();
                            con.Close();
                        }
                    }
                }
            }
            return RedirectToAction("GetListUser", "Home");
        }

        public IActionResult UpdateUser(Int64 id)
        {
            RegisterModel registerModel = new RegisterModel();
            string constr = _MyGlobalVariable.MySqlConString;
            if (constr != null)
            {
                string query = "SELECT ID, username, password, Name, Gender FROM user WHERE ID = " + id + " LIMIT 1;";
                using (MySqlConnection con = new MySqlConnection(constr))
                {
                    using (MySqlCommand cmd = new MySqlCommand(query))
                    {
                        cmd.Connection = con;
                        con.Open();
                        using (MySqlDataReader sdr = cmd.ExecuteReader())
                        {
                            while (sdr.Read())
                            {
                                registerModel.Id = Convert.ToInt64(sdr["ID"]);
                                registerModel.Username = sdr["username"].ToString();
                                registerModel.Password = sdr["password"].ToString();
                                registerModel.Name = sdr["Name"].ToString();
                                registerModel.Gender = sdr["Gender"].ToString();
                            }
                        }
                        con.Close();
                    }
                }
            }
            return View(registerModel);
        }

        //ActionUpdateUser
        public IActionResult ActionUpdateUser(RegisterModel mdl)
        {
            if (ModelState.IsValid)
            {
                string constr = _MyGlobalVariable.MySqlConString;
                if (constr != null)
                {
                    string query = "UPDATE user SET username = @username , password = @password, Name = @Name, Gender = @Gender WHERE ID = @Id;";
                    using (MySqlConnection con = new MySqlConnection(constr))
                    {
                        using (MySqlCommand cmd = new MySqlCommand(query))
                        {
                            cmd.Connection = con;
                            con.Open();
                            cmd.Parameters.AddWithValue("@username", mdl.Username);
                            cmd.Parameters.AddWithValue("@password", mdl.Password);
                            cmd.Parameters.AddWithValue("@Name", mdl.Name);
                            cmd.Parameters.AddWithValue("@Gender", mdl.Gender);
                            cmd.Parameters.AddWithValue("@Id", mdl.Id);
                            cmd.ExecuteNonQuery();
                            con.Close();
                        }
                    }
                }
            }
            return RedirectToAction("GetListUser", "Home");
        }

        //DeleteUser
        public IActionResult DeleteUser(Int64 id)
        {
            RegisterModel registerModel = new RegisterModel();
            string constr = _MyGlobalVariable.MySqlConString;
            if (constr != null)
            {
                string query = "SELECT ID, username, password, Name, Gender FROM user WHERE ID = " + id + " LIMIT 1;";
                using (MySqlConnection con = new MySqlConnection(constr))
                {
                    using (MySqlCommand cmd = new MySqlCommand(query))
                    {
                        cmd.Connection = con;
                        con.Open();
                        using (MySqlDataReader sdr = cmd.ExecuteReader())
                        {
                            while (sdr.Read())
                            {
                                registerModel.Id = Convert.ToInt64(sdr["ID"]);
                                registerModel.Username = sdr["username"].ToString();
                                registerModel.Password = sdr["password"].ToString();
                                registerModel.Name = sdr["Name"].ToString();
                                registerModel.Gender = sdr["Gender"].ToString();
                            }
                        }
                        con.Close();
                    }
                }
            }
            return View(registerModel);
        }

        public IActionResult ActionDeleteUser(RegisterModel usr)
        {
            if (usr.Id != 0)
            {
                string constr = _MyGlobalVariable.MySqlConString;
                if (constr != null)
                {
                    string query = "DELETE FROM user WHERE ID = @Id;";
                    using (MySqlConnection con = new MySqlConnection(constr))
                    {
                        using (MySqlCommand cmd = new MySqlCommand(query))
                        {
                            cmd.Connection = con;
                            con.Open();
                            cmd.Parameters.AddWithValue("@id", usr.Id);
                            cmd.ExecuteNonQuery();
                            con.Close();
                        }
                    }
                }
            }
            return RedirectToAction("GetListUser", "Home");
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}